# pilot2 0.2.0

- Convert Shiny application to a package structure using [`{golem}`](https://thinkr-open.github.io/golem).
- Incorporate the open-source [`{teal}`](https://insightsengineering.github.io/teal/main) package inside application to provide dynamic filters in all modules

# pilot2 0.1.0

- Initial version.
- Added a `NEWS.md` file to track changes to the package.
