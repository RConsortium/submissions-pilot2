utils::globalVariables(
  c(
    "TRT01P", "AGEGR1", "RACE", "EFFFL", "ITTFL", "PARAMCD", "ANL01FL", "TRTPN", 
    "AVISITN", "p.value", "contrast", "p", "diff_se",
    "ci", "value", "ord", "row_label", "54", "81", "row_label1", "ord_layer_index", "row_label2", "ord_layer_1", 
    "ord_layer_2", "TRTP", "USUBJID",
    "sd", "median", "AVAL", "CHG", ".", "TRTP", "BASE",
    "SE", "df", "N", "mean_bl",
    "sd_bl", "sd", "mean_chg", "sd_chg", 
    "emmean", "lower.CL", "upper.CL", "Trt",
    "CI", "estimate", "lower", "upper", "p.value",
    "comp", "SAFFL", "STUDYID", "USUBJID", "TRT01A",
    "AVAL", "CNSR", "PARAM", "PARAMCD", "anl", "TRTDUR", "TRTA", "TRTAN", "VISIT", "distinct_n",
    "distinct_pct", "var1_Placebo", "var1_Xanomeline High Dose", "var1_Xanomeline Low Dose",
    "var1_Total", "N_20", "y_values", "time"
  )
)